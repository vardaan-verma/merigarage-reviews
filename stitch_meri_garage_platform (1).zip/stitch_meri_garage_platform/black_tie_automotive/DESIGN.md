---
name: Black Tie Automotive
colors:
  surface: '#141313'
  surface-dim: '#141313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353434'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e8bcb7'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#af8783'
  outline-variant: '#5e3f3b'
  surface-tint: '#ffb4ab'
  primary: '#ffb4ab'
  on-primary: '#690006'
  primary-container: '#eb1620'
  on-primary-container: '#130000'
  inverse-primary: '#c00013'
  secondary: '#b0c6ff'
  on-secondary: '#002d6f'
  secondary-container: '#0351bc'
  on-secondary-container: '#bacdff'
  tertiary: '#ffb3ae'
  on-tertiary: '#68000b'
  tertiary-container: '#de3538'
  on-tertiary-container: '#140001'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000c'
  secondary-fixed: '#d9e2ff'
  secondary-fixed-dim: '#b0c6ff'
  on-secondary-fixed: '#001945'
  on-secondary-fixed-variant: '#00429c'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ae'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#141313'
  on-background: '#e5e2e1'
  surface-variant: '#353434'
  silver-border: '#CCCBCC'
  surface-elevated: '#0A0A0A'
  text-primary: '#FFFFFF'
  text-secondary: '#CCCBCC'
typography:
  display-lg:
    fontFamily: manrope
    fontSize: 56px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-xl:
    fontFamily: manrope
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-lg-mobile:
    fontFamily: manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-lg:
    fontFamily: manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: manrope
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.4'
    letterSpacing: 0.1em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  container-max: 1440px
  gap-xs: 4px
  gap-sm: 8px
  gap-md: 16px
  gap-lg: 32px
  gap-xl: 64px
---

## Brand & Style
The design system embodies the "Black Tie" aesthetic—a sophisticated, high-performance environment designed for the premium automotive sector. It targets an audience that values precision, speed, and luxury. The brand personality is authoritative yet energetic, mirroring the experience of a high-end night-time showroom.

The visual style is **High-Contrast Minimalism**. By utilizing a Deep Black foundation with hairline Silver borders, the system achieves a "machined" precision. The use of Crimson Red is surgical, reserved for high-value conversion points and critical status indicators, while Power Blue provides a technical, digital counterpoint for secondary navigation and utility. This is a design of extremes: deep voids, sharp highlights, and aggressive, energetic accents.

## Colors
The palette is optimized for a deep-dark environment where contrast is the primary driver of hierarchy.

- **Deep Black (#010101):** The absolute foundation. It provides an infinite depth that allows red and blue accents to "pop" with cinematic intensity.
- **Crimson Red (#EB1620):** The primary action color. It represents ignition and performance. Use this for the most critical CTAs (e.g., "Schedule Service," "Buy Now").
- **Power Blue (#0050BB):** The technical accent. Used for secondary interactive elements, links, and informational highlights to prevent "red fatigue" and signal digital utility.
- **Intense Red (#DE3538):** A tonal variation used for hover states of primary elements or urgent system alerts.
- **Silver (#CCCBCC):** Used for hairline borders and secondary text. It mimics the look of brushed aluminum or chrome against black leather.

## Typography
**Manrope** is used exclusively to maintain a modern, technical, and highly legible appearance. 

- **Headlines:** Set with tight tracking and heavy weights. In the dark theme, bold white text against black creates maximum impact.
- **Body Text:** Uses the Silver (#CCCBCC) variable for long-form content to reduce eye strain, while using pure white for emphasized snippets.
- **Labels:** Technical data, VINs, and spec sheets should use `label-sm` with increased letter spacing and uppercase styling to evoke the feeling of engraved serial numbers or dashboard readouts.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to maintain a gallery-like focus, transitioning to a fluid model on smaller screens.

- **Grid:** A 12-column grid with a 1440px maximum width. On desktop, large side margins (64px) frame the content like a luxury catalog.
- **Rhythm:** A 4px baseline grid ensures mechanical alignment. Larger gaps (`gap-xl`) are used between major content sections (e.g., Hero to Vehicle Specs) to provide visual breathing room.
- **Mobile Adaptivity:** Gutters shrink to 16px. Elements that are side-by-side on desktop (like car spec cards) should reflow into a single-column vertical stack.

## Elevation & Depth
In a Deep Black environment, traditional shadows are ineffective. Instead, depth is communicated through **Tonal Layers** and **Hairline Outlines**.

- **Level 0 (Base):** Deep Black (#010101).
- **Level 1 (Surface):** A slightly lifted black (#0A0A0A) used for cards and containers.
- **Outlines:** All elevated containers must use a 1px Silver (#CCCBCC) border at low opacity (15-20%) to define their edges against the void.
- **Glow Effects:** Primary buttons and active states may use a very subtle outer glow of Crimson Red (blur: 15px, opacity: 20%) to simulate illuminated dashboard components.

## Shapes
The design system utilizes **Pill-shaped (Level 3)** geometry. This creates a high-end, aerodynamic feel that contrasts beautifully with the rigid, high-contrast color palette.

- **Interactive Elements:** Buttons, chips, and input fields are fully pill-shaped.
- **Containers:** Large cards and modals use the `rounded-xl` (3rem) setting to maintain a consistent language of fluid, organic curves that mimic automotive bodywork.
- **Icons:** Should follow a rounded-cap stroke style to match the typography and shape language.

## Components

### Buttons
- **Primary (High-Value):** Solid Crimson Red (#EB1620) with white text. Full pill-shaped. Reserved for the ultimate conversion point.
- **Secondary (Utility):** Solid Power Blue (#0050BB) with white text. Used for "Add to Compare" or "Download Specs."
- **Ghost:** 1px Silver border with white text. Used for low-priority navigation.

### Inputs & Fields
- **Search/Text Fields:** Deep Black background with a 1px Silver border (20% opacity). On focus, the border becomes solid Power Blue with a faint glow.
- **Selection:** Pill-shaped chips. Inactive: Silver border, no fill. Active: Power Blue fill with white text.

### Cards
- **Vehicle Display:** Surface-elevated (#0A0A0A) background, 3rem corner radius, 1px Silver hairline border. Images should have a subtle gradient fade to black at the bottom to blend into the card.

### Status Indicators
- **Performance Tiers:** Use Crimson Red for "Sport/High" and Power Blue for "Eco/Efficiency."
- **Availability:** A pulse animation in Crimson Red for "Limited Stock" creates a sense of urgency against the static black background.