---
name: Premium Automotive Concierge
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c6c6cd'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#909097'
  outline-variant: '#45464d'
  surface-tint: '#bec6e0'
  primary: '#bec6e0'
  on-primary: '#283044'
  primary-container: '#0f172a'
  on-primary-container: '#798098'
  inverse-primary: '#565e74'
  secondary: '#b4c5ff'
  on-secondary: '#002a78'
  secondary-container: '#0053db'
  on-secondary-container: '#cdd7ff'
  tertiary: '#ffb4a8'
  on-tertiary: '#690001'
  tertiary-container: '#390000'
  on-tertiary-container: '#fe1812'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4a8'
  on-tertiary-fixed: '#410000'
  on-tertiary-fixed-variant: '#930002'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.04em
  headline-xl:
    fontFamily: Manrope
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  stack-xs: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  stack-xl: 48px
  stack-2xl: 80px
---

## Brand & Style

This design system is engineered to bridge the gap between high-end automotive care and sophisticated digital interfaces. It targets discerning vehicle owners who demand precision, reliability, and a white-glove service experience. The visual identity follows a **Premium Modern** aesthetic, blending the technical rigor of automotive engineering with the airy, refined feel of a luxury showroom.

The style leverages **Minimalism** and **Tonal Layering** to create a focused, high-end environment. By using deep, authoritative tones against expansive whitespace, the UI evokes a sense of "digital grease-free" cleanliness. The combination of geometric precision and organic roundedness reflects the intersection of mechanical excellence and human-centric service.

## Colors

The palette is anchored in a dark-mode execution to evoke a high-end showroom feel.

- **Deep Navy (#0f172a):** The foundation of the system. Used as the primary immersive background to establish authority and trust.
- **Energetic Blue (#2563eb):** The primary driver for digital interactions. It signals tech-forwardness and is reserved for standard secondary actions and interactive focus states.
- **Vibrant Red (#f50a0a):** A purposeful automotive accent. This high-visibility color is strictly reserved for urgent automotive CTAs, critical alerts, and high-priority status indicators.
- **Surface Strategy:** Layers are built using incremental lightness. Cards and containers use `#1e293b` to lift content off the deep background, while borders use `#334155` for structural definition without harsh contrast.

## Typography

The design system utilizes **Manrope** across all levels to maintain a unified, tech-driven, and architectural appearance. 

- **Headlines:** Use tighter letter spacing and heavier weights to project confidence. The scale is optimized for wide screens, providing a dramatic hierarchy that guides the user through complex automotive data.
- **Body:** Leverages the modern, open apertures of Manrope to ensure high legibility in service descriptions and technical specifications.
- **Labels:** Uppercase styles are used for technical metadata (e.g., VIN numbers, part categories) to differentiate data from prose.
- **Responsive Scaling:** Display and XL headlines automatically scale down for mobile viewports to prevent awkward line breaks while maintaining their stylistic impact.

## Layout & Spacing

The layout philosophy centers on **Generous Breathing Room**, ensuring the interface feels as organized and precise as a high-end garage.

- **Grid Model:** A 12-column fluid grid is used for desktop (max-width 1280px). Elements should align to the grid to maintain a "structured engineering" feel.
- **Vertical Rhythm:** A strict 4px base unit governs all spacing. Use `stack-xl` (48px) for major section breaks to prevent the UI from feeling crowded by technical data.
- **Desktop Focus:** On wide screens, utilize increased side margins (`64px`) to center the user's focus on the concierge content.
- **Reflow:** For mobile, the grid collapses to 4 columns with 16px margins, and internal card padding reduces from `stack-lg` to `stack-md`.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows** that respect the dark-mode aesthetic.

- **Layer 0 (Base):** Deep Navy (#0f172a). All background content resides here.
- **Layer 1 (Standard Card):** Surface color (#1e293b) with a subtle 1px border (#334155). This creates a "machined" look.
- **Layer 2 (Elevated/Hover):** Surfaces use a tinted ambient shadow: `0px 12px 32px rgba(0, 0, 0, 0.4)`. This suggests the component is physically lifted toward the viewer.
- **Glassmorphism:** Navigation bars and sticky headers should use a backdrop blur (12px) with a semi-transparent Deep Navy fill (80% opacity) to maintain context of the content scrolling beneath them.

## Shapes

The design system employs a **Rounded (Level 2)** roundedness strategy to balance mechanical precision with an approachable, modern feel.

- **Buttons:** Use standard rounded corners (`1rem`) to maintain structural integrity while remaining interactive.
- **Cards:** Main service and garage cards utilize a `1.5rem` (MD) radius to ensure they feel modern but structurally sound.
- **Inputs:** Use a consistent `1rem` radius to align with the soft-tech aesthetic.
- **Badges/Chips:** Fully rounded to represent "tappable" units of information.

## Components

### Buttons
- **Automotive CTA:** Solid Vibrant Red (#f50a0a) with white text. Reserved for urgent actions like "Book Now" or "Approve Quote."
- **Secondary Action:** Solid Energetic Blue (#2563eb) with white text. Used for "View Details" or "Filter."
- **Ghost/Outline:** 1px border of Energetic Blue with matching text for tertiary actions.

### Cards & Lists
- **Service Cards:** Surface color background with a 1.5rem radius. Headlines use `headline-sm`. Include a subtle border to define the shape against the dark background.
- **Garage Lists:** Use `stack-md` spacing between list items. Use horizontal dividers (#334155) only when the list is dense.

### Inputs & Selection
- **Text Fields:** Darker surface fill than the background with a 1px border. On focus, the border glows with Energetic Blue.
- **Checkboxes/Radios:** Use Energetic Blue for the active state. The roundedness of the checkbox should be 4px to maintain a hint of the system's geometry.

### Automotive Specifics
- **Verified Badge:** A success-green pill badge with a white checkmark. Use `label-sm` for the text.
- **Rating Stars:** Use Vibrant Red for filled stars in critical contexts, or default accent colors. Use `label-lg` for the numeric value positioned immediately to the right.
- **Service Chips:** Use a subtle border and no fill for inactive states. On selection, fill with Energetic Blue or Deep Navy depending on the intensity required.